import java.util.Scanner;
public class Reverse {
	public static void main(String args[])
	{
		String s1;
		System.out.println("enter");
		Scanner sc=new Scanner(System.in);
		s1=sc.next();
		char ch[]=s1.toCharArray();
		String rev="";
		for(int i=ch.length-1;i>=0;i--)
		{
			rev+=ch[i];
			
		}
		return rev;
		
	}

}
