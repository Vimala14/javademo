package SamplePackage;

public class Sam {

}
